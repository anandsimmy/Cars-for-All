<div class="different_filters_divbox">                                            
	<ul class="different_filters">
			
		<li>
			<input type="radio" name="price_range" id="price_range1" value="30-50" class="price_range"/>
			<label for="price_range1">30 - 50 lakhs</label>
		</li>
		<li>
			<input type="radio" name="price_range" id="price_range2" value="51-70" class="price_range"/>
			<label for="price_range2">51 - 70 lakhs</label>
		</li>
		<li>
			<input type="radio" name="price_range" id="price_range3" value="71-90" class="price_range"/>
			<label for="price_range3">71 - 90 lakhs</label>
		</li>
		<li>
			<input type="radio" name="price_range" id="price_range4" value="91-120" class="price_range"/>
			<label for="price_range4">91 - 120 lakhs</label>
		</li>
		
		
	</ul>
</div>